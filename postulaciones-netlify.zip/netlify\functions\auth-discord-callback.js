const {
  clearSessionCookie,
  commitSession,
  createEmptySession,
  getDiscordConfig,
  getDiscordCurrentGuildMember,
  getDiscordCurrentUser,
  getDiscordOAuthToken,
  getMissingConfig,
  readSession,
  redirect
} = require("./shared");

exports.handler = async (event) => {
  const config = getDiscordConfig(event);
  const missing = getMissingConfig(config, ["clientId", "clientSecret", "redirectUri", "guildId"]);

  if (missing.length > 0) {
    return redirect("/?discord=error", {
      headers: {
        "Set-Cookie": clearSessionCookie(event)
      }
    });
  }

  const session = readSession(event);
  const query = event.queryStringParameters || {};
  const code = String(query.code || "").trim();
  const state = String(query.state || "").trim();

  if (!code || !state) {
    return redirect("/?discord=error", {
      headers: {
        "Set-Cookie": clearSessionCookie(event)
      }
    });
  }

  if (state !== session.oauthState) {
    return redirect("/?discord=state_error", {
      headers: {
        "Set-Cookie": clearSessionCookie(event)
      }
    });
  }

  try {
    const token = await getDiscordOAuthToken(config, code);
    const user = await getDiscordCurrentUser(token.access_token);
    await getDiscordCurrentGuildMember(token.access_token, config.guildId);

    const displayName = String(user.global_name || user.username || "").trim() || String(user.username || "").trim();
    const nextSession = createEmptySession();
    nextSession.createdAt = session.createdAt;
    nextSession.authenticated = true;
    nextSession.verifiedGuildMember = true;
    nextSession.discordUsername = `${displayName} (@${user.username}) | ${user.id}`;
    nextSession.discordUserId = String(user.id || "");

    return redirect("/?discord=verified", {
      headers: {
        "Set-Cookie": commitSession(event, nextSession)
      }
    });
  } catch (error) {
    const discordStatus = error && error.statusCode === 404 ? "not_in_server" : "error";

    return redirect(`/?discord=${discordStatus}`, {
      headers: {
        "Set-Cookie": clearSessionCookie(event)
      }
    });
  }
};
