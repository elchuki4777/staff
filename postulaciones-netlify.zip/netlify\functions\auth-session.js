const { json, readSession, sessionToResponse } = require("./shared");

exports.handler = async (event) => {
  const session = readSession(event);

  return json(200, {
    ok: true,
    ...sessionToResponse(session)
  });
};
