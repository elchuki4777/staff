const { clearSessionCookie, json, methodNotAllowed } = require("./shared");

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return methodNotAllowed();
  }

  return json(200, {
    ok: true
  }, {
    headers: {
      "Set-Cookie": clearSessionCookie(event)
    }
  });
};
