const {
  buildDiscordPayloads,
  getDiscordConfig,
  json,
  methodNotAllowed,
  postToWebhook,
  readSession,
  validateApplicationPayload
} = require("./shared");

function readRequestBody(event) {
  if (!event.body) {
    return null;
  }

  const rawBody = event.isBase64Encoded
    ? Buffer.from(event.body, "base64").toString("utf8")
    : event.body;

  return JSON.parse(rawBody);
}

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return methodNotAllowed();
  }

  const config = getDiscordConfig(event);
  if (!String(config.webhookUrl || "").trim()) {
    return json(500, {
      ok: false,
      message: "Configura DISCORD_WEBHOOK_URL antes de enviar postulaciones."
    });
  }

  const session = readSession(event);
  if (!session.verifiedGuildMember) {
    return json(403, {
      ok: false,
      message: "Debes verificar tu cuenta de Discord antes de enviar la postulacion."
    });
  }

  let data = null;

  try {
    data = readRequestBody(event);
  } catch {
    return json(400, {
      ok: false,
      message: "El cuerpo de la solicitud no es un JSON valido."
    });
  }

  data.discordUsername = session.discordUsername;
  const validation = validateApplicationPayload(data);

  if (!validation.isValid) {
    return json(400, {
      ok: false,
      message: `Faltan campos obligatorios: ${validation.missing.join(", ")}`
    });
  }

  try {
    const payloads = buildDiscordPayloads(data);

    for (const payload of payloads) {
      await postToWebhook(config.webhookUrl, payload);
    }

    return json(200, {
      ok: true,
      message: "Postulacion enviada correctamente."
    });
  } catch (error) {
    return json(500, {
      ok: false,
      message: error instanceof Error && error.message
        ? error.message
        : "Ocurrio un error al enviar la postulacion."
    });
  }
};
