# Formulario de postulacion para staff

Proyecto simple con:

- Interfaz de acceso simple y profesional
- Verificacion real con Discord antes de entrar al formulario
- Formulario de postulacion para un server de Discord
- Envio privado a un canal interno mediante webhook
- Servidor local en PowerShell, sin Node ni dependencias
- Compatibilidad con Netlify Functions para deploy online

## Archivos principales

- `index.html`: estructura de la pagina
- `styles.css`: estilos visuales
- `app.js`: logica del formulario y envio al backend
- `server.ps1`: servidor local y proxy hacia Discord

## Como usarlo en local

1. Configura tu aplicacion de Discord OAuth.
   En el Developer Portal agrega este `Redirect URI`:

```text
http://localhost:8080/api/auth/discord/callback
```

   Usa los scopes `identify` y `guilds.members.read`.

1. Crea un canal privado en Discord para revisar postulaciones.
2. Dentro de ese canal, crea un webhook.
   El enlace del canal `https://discord.com/channels/...` no sirve como endpoint de envio.
   Debes crear un webhook en ese mismo canal para que las postulaciones lleguen ahi.
3. En PowerShell, configura la variable:

```powershell
$env:DISCORD_WEBHOOK_URL = "https://discord.com/api/webhooks/TU_ID/TU_TOKEN"
```

Tambien puedes dejar el webhook guardado localmente en `discord-webhook.local.txt`.
Ese archivo ya esta ignorado en `.gitignore`.
Como referencia, este repo incluye `discord-webhook.local.example.txt`.

Tambien puedes guardar la configuracion OAuth en `discord-oauth.local.json` con este formato:

```json
{
  "clientId": "TU_CLIENT_ID",
  "clientSecret": "TU_CLIENT_SECRET",
  "guildId": "TU_SERVER_ID",
  "redirectUri": "http://localhost:8080/api/auth/discord/callback"
}
```

Como referencia, este repo incluye `discord-oauth.local.example.json`.

4. Inicia el servidor desde esta carpeta:

```powershell
powershell -ExecutionPolicy Bypass -File .\server.ps1
```

5. Abre en tu navegador:

```text
http://localhost:8080
```

## Como desplegarlo en Netlify

Este repo ya incluye `netlify.toml` y funciones en `netlify/functions` para que las rutas `/api/...` funcionen en un deploy estatico.

Si publicas con Netlify Drop, no subas archivos locales con secretos como `discord-webhook.local.txt` o `discord-oauth.local.json`.
Para deploy online usa variables de entorno en Netlify y deja solo los archivos `.example` dentro de la carpeta del proyecto.

Configura estas variables de entorno en Netlify:

```text
DISCORD_CLIENT_ID
DISCORD_CLIENT_SECRET
DISCORD_GUILD_ID
DISCORD_WEBHOOK_URL
SESSION_SECRET
```

Tambien puedes definir:

```text
DISCORD_REDIRECT_URI
```

Si no la defines, el deploy intentara usar automaticamente:

```text
https://TU-SITIO/api/auth/discord/callback
```

En Discord Developer Portal debes registrar exactamente ese callback del sitio publicado.

## Error comun: `Unexpected token '<'`

Si ves ese error o una pagina `404` de Netlify al verificar Discord, significa que el frontend recibio HTML en vez de JSON.

Las causas mas comunes son:

- El sitio estaba desplegado sin las funciones `/api`.
- Faltan variables de entorno en Netlify.
- El `Redirect URI` configurado en Discord no coincide con el dominio publicado.

## Notas

- Si abres `index.html` con doble clic, veras la pagina pero el formulario no podra enviarse.
- El webhook queda escondido en el servidor y no se expone en el frontend.
- Si luego quieres, podemos convertir esto en una version con base de datos, panel admin o deploy online.
