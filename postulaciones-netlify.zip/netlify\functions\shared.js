const crypto = require("node:crypto");

const SESSION_COOKIE_NAME = "staff_portal_session";
const SESSION_MAX_AGE_SECONDS = 60 * 60 * 8;

function createEmptySession() {
  return {
    createdAt: new Date().toISOString(),
    authenticated: false,
    verifiedGuildMember: false,
    discordUsername: "",
    discordUserId: "",
    oauthState: ""
  };
}

function normalizeSession(session = {}) {
  return {
    createdAt: typeof session.createdAt === "string" ? session.createdAt : new Date().toISOString(),
    authenticated: Boolean(session.authenticated),
    verifiedGuildMember: Boolean(session.verifiedGuildMember),
    discordUsername: typeof session.discordUsername === "string" ? session.discordUsername : "",
    discordUserId: typeof session.discordUserId === "string" ? session.discordUserId : "",
    oauthState: typeof session.oauthState === "string" ? session.oauthState : ""
  };
}

function getHeader(event, name) {
  const target = name.toLowerCase();
  const headers = event && event.headers ? event.headers : {};

  for (const [key, value] of Object.entries(headers)) {
    if (key.toLowerCase() === target) {
      return value;
    }
  }

  return "";
}

function isSecureRequest(event) {
  const forwardedProto = String(getHeader(event, "x-forwarded-proto") || "").split(",")[0].trim().toLowerCase();
  if (forwardedProto) {
    return forwardedProto === "https";
  }

  const siteUrl = process.env.URL || process.env.DEPLOY_PRIME_URL || "";
  return siteUrl.startsWith("https://");
}

function getRequestOrigin(event) {
  const host = String(getHeader(event, "x-forwarded-host") || getHeader(event, "host") || "").trim();
  if (!host) {
    return process.env.URL || process.env.DEPLOY_PRIME_URL || "";
  }

  const forwardedProto = String(getHeader(event, "x-forwarded-proto") || "").split(",")[0].trim().toLowerCase();
  const protocol = forwardedProto || (isSecureRequest(event) ? "https" : "http");
  return `${protocol}://${host}`;
}

function getSessionSecret() {
  return process.env.SESSION_SECRET || process.env.DISCORD_CLIENT_SECRET || "";
}

function randomToken() {
  return crypto.randomBytes(32).toString("hex");
}

function parseCookies(cookieHeader = "") {
  const cookies = {};

  for (const piece of String(cookieHeader || "").split(";")) {
    const trimmed = piece.trim();
    if (!trimmed) {
      continue;
    }

    const separatorIndex = trimmed.indexOf("=");
    if (separatorIndex === -1) {
      continue;
    }

    const name = trimmed.slice(0, separatorIndex).trim();
    const value = trimmed.slice(separatorIndex + 1).trim();
    cookies[name] = decodeURIComponent(value);
  }

  return cookies;
}

function serializeCookie(name, value, options = {}) {
  const parts = [`${name}=${encodeURIComponent(value)}`, `Path=${options.path || "/"}`];

  if (typeof options.maxAge === "number") {
    parts.push(`Max-Age=${Math.max(0, Math.floor(options.maxAge))}`);
  }

  if (options.expires instanceof Date) {
    parts.push(`Expires=${options.expires.toUTCString()}`);
  }

  if (options.httpOnly !== false) {
    parts.push("HttpOnly");
  }

  if (options.sameSite) {
    parts.push(`SameSite=${options.sameSite}`);
  }

  if (options.secure) {
    parts.push("Secure");
  }

  return parts.join("; ");
}

function base64UrlEncode(value) {
  return Buffer.from(value, "utf8")
    .toString("base64")
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/g, "");
}

function base64UrlDecode(value) {
  const normalized = String(value || "").replace(/-/g, "+").replace(/_/g, "/");
  const padding = (4 - (normalized.length % 4)) % 4;
  return Buffer.from(normalized + "=".repeat(padding), "base64").toString("utf8");
}

function signValue(value, secret) {
  return crypto.createHmac("sha256", secret)
    .update(value)
    .digest("base64")
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/g, "");
}

function safeEqualString(left, right) {
  const leftBuffer = Buffer.from(String(left || ""), "utf8");
  const rightBuffer = Buffer.from(String(right || ""), "utf8");

  if (leftBuffer.length !== rightBuffer.length) {
    return false;
  }

  return crypto.timingSafeEqual(leftBuffer, rightBuffer);
}

function readSession(event) {
  const cookies = parseCookies(getHeader(event, "cookie"));
  const rawValue = cookies[SESSION_COOKIE_NAME];
  const empty = createEmptySession();

  if (!rawValue) {
    return empty;
  }

  const separatorIndex = rawValue.lastIndexOf(".");
  if (separatorIndex === -1) {
    return empty;
  }

  const encodedPayload = rawValue.slice(0, separatorIndex);
  const receivedSignature = rawValue.slice(separatorIndex + 1);
  const secret = getSessionSecret();

  if (!secret) {
    return empty;
  }

  const expectedSignature = signValue(encodedPayload, secret);
  if (!safeEqualString(receivedSignature, expectedSignature)) {
    return empty;
  }

  try {
    return normalizeSession(JSON.parse(base64UrlDecode(encodedPayload)));
  } catch {
    return empty;
  }
}

function commitSession(event, session) {
  const secret = getSessionSecret();
  if (!secret) {
    throw new Error("Falta configurar SESSION_SECRET o DISCORD_CLIENT_SECRET.");
  }

  const encodedPayload = base64UrlEncode(JSON.stringify(normalizeSession(session)));
  const signature = signValue(encodedPayload, secret);

  return serializeCookie(SESSION_COOKIE_NAME, `${encodedPayload}.${signature}`, {
    path: "/",
    maxAge: SESSION_MAX_AGE_SECONDS,
    httpOnly: true,
    sameSite: "Lax",
    secure: isSecureRequest(event)
  });
}

function clearSessionCookie(event) {
  return serializeCookie(SESSION_COOKIE_NAME, "", {
    path: "/",
    maxAge: 0,
    expires: new Date(0),
    httpOnly: true,
    sameSite: "Lax",
    secure: isSecureRequest(event)
  });
}

function json(statusCode, payload, extra = {}) {
  return {
    statusCode,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store",
      ...(extra.headers || {})
    },
    body: JSON.stringify(payload)
  };
}

function redirect(location, extra = {}) {
  return {
    statusCode: 302,
    headers: {
      Location: location,
      "Cache-Control": "no-store",
      ...(extra.headers || {})
    },
    body: ""
  };
}

function methodNotAllowed() {
  return json(405, {
    ok: false,
    message: "Metodo no permitido."
  });
}

function getDiscordConfig(event) {
  const origin = getRequestOrigin(event);

  return {
    clientId: process.env.DISCORD_CLIENT_ID || "",
    clientSecret: process.env.DISCORD_CLIENT_SECRET || "",
    guildId: process.env.DISCORD_GUILD_ID || "",
    redirectUri: process.env.DISCORD_REDIRECT_URI || (origin ? `${origin}/api/auth/discord/callback` : ""),
    webhookUrl: process.env.DISCORD_WEBHOOK_URL || ""
  };
}

function getMissingConfig(config, requiredKeys) {
  return requiredKeys.filter((key) => !String(config[key] || "").trim());
}

function getDiscordAuthorizationUrl(config, state) {
  const url = new URL("https://discord.com/oauth2/authorize");
  url.searchParams.set("client_id", config.clientId);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("redirect_uri", config.redirectUri);
  url.searchParams.set("scope", "identify guilds.members.read");
  url.searchParams.set("prompt", "consent");
  url.searchParams.set("state", state);
  return url.toString();
}

async function fetchDiscordJson(url, options = {}) {
  const response = await fetch(url, options);
  const rawBody = await response.text();
  let data = null;

  if (rawBody) {
    try {
      data = JSON.parse(rawBody);
    } catch {
      data = null;
    }
  }

  if (!response.ok) {
    const error = new Error(
      data && typeof data.message === "string"
        ? data.message
        : `Discord devolvio un estado ${response.status}.`
    );
    error.statusCode = response.status;
    error.responseText = rawBody;
    throw error;
  }

  return data || {};
}

async function getDiscordOAuthToken(config, code) {
  const body = new URLSearchParams({
    client_id: config.clientId,
    client_secret: config.clientSecret,
    grant_type: "authorization_code",
    code,
    redirect_uri: config.redirectUri
  });

  return fetchDiscordJson("https://discord.com/api/v10/oauth2/token", {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded"
    },
    body: body.toString()
  });
}

async function getDiscordCurrentUser(accessToken) {
  return fetchDiscordJson("https://discord.com/api/v10/users/@me", {
    method: "GET",
    headers: {
      Authorization: `Bearer ${accessToken}`
    }
  });
}

async function getDiscordCurrentGuildMember(accessToken, guildId) {
  return fetchDiscordJson(`https://discord.com/api/v10/users/@me/guilds/${guildId}/member`, {
    method: "GET",
    headers: {
      Authorization: `Bearer ${accessToken}`
    }
  });
}

function limitText(value, maxLength = 700) {
  if (typeof value !== "string" || !value.trim()) {
    return "No especificado";
  }

  const trimmed = value.replace(/\r?\n+/g, " ").trim().replace(/\s{2,}/g, " ");
  if (trimmed.length <= maxLength) {
    return trimmed;
  }

  return `${trimmed.slice(0, maxLength - 3)}...`;
}

function buildDiscordLines(data) {
  return [
    "POSTULACION STAFF - BAJO MUNDO RP",
    "",
    "INFORMACION BASICA",
    `- Discord: ${limitText(data.discordUsername, 180)}`,
    `- Roblox: ${limitText(data.robloxUsername, 120)}`,
    `- Edad: ${limitText(String(data.age || ""), 20)}`,
    `- Pais: ${limitText(data.country, 80)}`,
    `- Horario disponible: ${limitText(data.schedule, 120)}`,
    `- Horas al dia: ${limitText(String(data.dailyHours || ""), 20)}`,
    "",
    "EXPERIENCIA",
    `- Ha sido staff en otros servidores: ${limitText(data.hasStaffExperience, 20)}`,
    `- Si si, en cuales: ${limitText(data.previousServers, 320)}`,
    `- Que rango tenia: ${limitText(data.previousRank, 120)}`,
    `- Por que ya no es staff alli: ${limitText(data.leftReason, 220)}`,
    `- Tiene experiencia en servidores RP: ${limitText(data.hasRpExperience, 20)}`,
    "",
    "CONOCIMIENTO DEL SERVIDOR",
    `- Desde cuando esta en Bajo Mundo RP: ${limitText(data.joinedSince, 120)}`,
    `- Conoce bien las reglas: ${limitText(data.knowsRules, 20)}`,
    `- Menciona 3 reglas importantes: ${limitText(data.importantRules)}`,
    `- Que haria si un usuario rompe una regla grave: ${limitText(data.severeRuleBreak)}`,
    "",
    "SITUACIONES",
    `- Si dos usuarios se insultan en chat: ${limitText(data.chatInsults)}`,
    `- Si un staff abusa de su poder: ${limitText(data.abusiveStaff)}`,
    `- Si un amigo rompe las reglas, lo sanciona: ${limitText(data.friendBreaksRules)}`,
    "",
    "ACTITUD Y COMPROMISO",
    `- Por que quiere ser staff: ${limitText(data.whyStaff)}`,
    `- Que lo diferencia de otros postulantes: ${limitText(data.uniqueValue)}`,
    `- Sabe trabajar en equipo: ${limitText(data.teamwork, 20)}`,
    `- Aceptaria criticas y supervision: ${limitText(data.acceptsCriticism, 20)}`,
    "",
    "NORMAS FINALES",
    `- Acepta remocion inmediata por abuso: ${limitText(data.acceptsRemoval, 20)}`,
    `- Promete ser activo y responsable: ${limitText(data.promisesActivity, 20)}`,
    "- Confirmo que lei las reglas y la informacion es real: Si",
    "",
    "EXTRA OPCIONAL",
    `- Mini anuncio: ${limitText(data.miniAnnouncement)}`,
    `- Que mejoraria en Bajo Mundo RP: ${limitText(data.serverImprovements)}`
  ];
}

function splitDiscordContent(lines, limit = 1800) {
  const chunks = [];
  let currentChunk = "";

  for (const line of lines) {
    const candidate = currentChunk ? `${currentChunk}\n${line}` : line;
    if (candidate.length <= limit) {
      currentChunk = candidate;
      continue;
    }

    if (currentChunk) {
      chunks.push(currentChunk);
    }

    if (line.length <= limit) {
      currentChunk = line;
      continue;
    }

    let remaining = line;
    while (remaining.length > limit) {
      chunks.push(remaining.slice(0, limit));
      remaining = remaining.slice(limit);
    }
    currentChunk = remaining;
  }

  if (currentChunk) {
    chunks.push(currentChunk);
  }

  return chunks;
}

function buildDiscordPayloads(data) {
  const chunks = splitDiscordContent(buildDiscordLines(data));

  return chunks.map((content, index) => ({
    username: "Bajo Mundo RP Staff",
    content: index === 0 ? content : `CONTINUA POSTULACION (${index + 1}/${chunks.length})\n\n${content}`,
    allowed_mentions: {
      parse: []
    }
  }));
}

function validateApplicationPayload(data) {
  if (!data || typeof data !== "object") {
    return {
      isValid: false,
      missing: ["payload"]
    };
  }

  const requiredFields = [
    "robloxUsername",
    "discordUsername",
    "age",
    "country",
    "schedule",
    "dailyHours",
    "hasStaffExperience",
    "hasRpExperience",
    "joinedSince",
    "knowsRules",
    "importantRules",
    "severeRuleBreak",
    "chatInsults",
    "abusiveStaff",
    "friendBreaksRules",
    "whyStaff",
    "uniqueValue",
    "teamwork",
    "acceptsCriticism",
    "acceptsRemoval",
    "promisesActivity"
  ];

  const missing = [];

  for (const field of requiredFields) {
    if (!String(data[field] || "").trim()) {
      missing.push(field);
    }
  }

  if (!data.agreeRules) {
    missing.push("agreeRules");
  }

  return {
    isValid: missing.length === 0,
    missing
  };
}

function sessionToResponse(session) {
  const normalized = normalizeSession(session);

  return {
    authenticated: normalized.authenticated,
    verifiedGuildMember: normalized.verifiedGuildMember,
    discordUsername: normalized.discordUsername,
    discordUserId: normalized.discordUserId
  };
}

async function postToWebhook(webhookUrl, payload) {
  const response = await fetch(webhookUrl, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(payload)
  });

  const rawBody = await response.text();
  if (!response.ok) {
    throw new Error(rawBody || `No se pudo enviar al webhook (${response.status}).`);
  }
}

module.exports = {
  buildDiscordPayloads,
  clearSessionCookie,
  commitSession,
  createEmptySession,
  getDiscordAuthorizationUrl,
  getDiscordConfig,
  getDiscordCurrentGuildMember,
  getDiscordCurrentUser,
  getDiscordOAuthToken,
  getMissingConfig,
  json,
  methodNotAllowed,
  postToWebhook,
  randomToken,
  readSession,
  redirect,
  sessionToResponse,
  validateApplicationPayload
};
