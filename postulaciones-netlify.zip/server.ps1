param(
  [int]$Port = 8080,
  [string]$Root = $PSScriptRoot,
  [string]$WebhookUrl = $env:DISCORD_WEBHOOK_URL
)

$ErrorActionPreference = "Stop"
$script:SessionCookieName = "staff_portal_session"
$script:Sessions = @{}
$script:DiscordConfig = $null

if ([string]::IsNullOrWhiteSpace($WebhookUrl)) {
  $localWebhookPath = Join-Path $PSScriptRoot "discord-webhook.local.txt"
  if (Test-Path -LiteralPath $localWebhookPath -PathType Leaf) {
    $WebhookUrl = [System.IO.File]::ReadAllText($localWebhookPath).Trim()
  }
}

$oauthConfigPath = Join-Path $PSScriptRoot "discord-oauth.local.json"
if (Test-Path -LiteralPath $oauthConfigPath -PathType Leaf) {
  try {
    $script:DiscordConfig = Get-Content -LiteralPath $oauthConfigPath -Raw | ConvertFrom-Json
  } catch {
    Write-Host "Aviso: no se pudo leer discord-oauth.local.json" -ForegroundColor Yellow
  }
}

function New-RandomToken {
  return [Guid]::NewGuid().ToString("N") + [Guid]::NewGuid().ToString("N")
}

function Set-SessionCookie {
  param(
    [Parameter(Mandatory = $true)]$Response,
    [Parameter(Mandatory = $true)][string]$Value,
    [datetime]$Expires = (Get-Date).AddHours(8)
  )

  $cookie = New-Object System.Net.Cookie($script:SessionCookieName, $Value)
  $cookie.Path = "/"
  $cookie.HttpOnly = $true
  $cookie.Expires = $Expires
  $Response.SetCookie($cookie)
}

function Get-OrCreate-Session {
  param(
    [Parameter(Mandatory = $true)]$Request,
    [Parameter(Mandatory = $true)]$Response
  )

  $sessionId = ""
  if ($null -ne $Request.Cookies[$script:SessionCookieName]) {
    $sessionId = $Request.Cookies[$script:SessionCookieName].Value
  }

  if ([string]::IsNullOrWhiteSpace($sessionId) -or -not $script:Sessions.ContainsKey($sessionId)) {
    $sessionId = New-RandomToken
    $script:Sessions[$sessionId] = @{
      CreatedAt = Get-Date
      Authenticated = $false
      VerifiedGuildMember = $false
      DiscordUsername = ""
      DiscordUserId = ""
      OAuthState = ""
    }
    Set-SessionCookie -Response $Response -Value $sessionId
  }

  return @{
    Id = $sessionId
    Data = $script:Sessions[$sessionId]
  }
}

function Send-RedirectResponse {
  param(
    [Parameter(Mandatory = $true)]$Response,
    [Parameter(Mandatory = $true)][string]$Location
  )

  $Response.StatusCode = 302
  $Response.RedirectLocation = $Location
  $Response.OutputStream.Close()
}

function Get-DiscordConfigValue {
  param(
    [Parameter(Mandatory = $true)][string]$Name
  )

  $envName = switch ($Name) {
    "clientId" { "DISCORD_CLIENT_ID" }
    "clientSecret" { "DISCORD_CLIENT_SECRET" }
    "guildId" { "DISCORD_GUILD_ID" }
    "redirectUri" { "DISCORD_REDIRECT_URI" }
    default { "" }
  }

  $envValue = if (-not [string]::IsNullOrWhiteSpace($envName)) { [Environment]::GetEnvironmentVariable($envName) } else { "" }
  if (-not [string]::IsNullOrWhiteSpace($envValue)) {
    return $envValue
  }

  if ($null -ne $script:DiscordConfig -and $null -ne $script:DiscordConfig.$Name -and -not [string]::IsNullOrWhiteSpace([string]$script:DiscordConfig.$Name)) {
    return [string]$script:DiscordConfig.$Name
  }

  return ""
}

function Get-FormUrlEncodedBody {
  param([hashtable]$Data)

  $pairs = foreach ($key in $Data.Keys) {
    [System.Uri]::EscapeDataString([string]$key) + "=" + [System.Uri]::EscapeDataString([string]$Data[$key])
  }

  return ($pairs -join "&")
}

function Get-StatusCodeFromException {
  param($Exception)

  try {
    return [int]$Exception.Response.StatusCode
  } catch {
    return 0
  }
}

function Get-DiscordAuthorizationUrl {
  param(
    [Parameter(Mandatory = $true)][string]$ClientId,
    [Parameter(Mandatory = $true)][string]$RedirectUri,
    [Parameter(Mandatory = $true)][string]$State
  )

  $query = @{
    client_id = $ClientId
    response_type = "code"
    redirect_uri = $RedirectUri
    scope = "identify guilds.members.read"
    prompt = "consent"
    state = $State
  }

  $pairs = foreach ($key in $query.Keys) {
    [System.Uri]::EscapeDataString($key) + "=" + [System.Uri]::EscapeDataString([string]$query[$key])
  }

  return "https://discord.com/oauth2/authorize?" + ($pairs -join "&")
}

function Get-DiscordOAuthToken {
  param(
    [Parameter(Mandatory = $true)][string]$ClientId,
    [Parameter(Mandatory = $true)][string]$ClientSecret,
    [Parameter(Mandatory = $true)][string]$RedirectUri,
    [Parameter(Mandatory = $true)][string]$Code
  )

  $body = Get-FormUrlEncodedBody -Data @{
    client_id = $ClientId
    client_secret = $ClientSecret
    grant_type = "authorization_code"
    code = $Code
    redirect_uri = $RedirectUri
  }

  return Invoke-RestMethod `
    -Uri "https://discord.com/api/v10/oauth2/token" `
    -Method POST `
    -ContentType "application/x-www-form-urlencoded" `
    -Body $body
}

function Get-DiscordCurrentUser {
  param([Parameter(Mandatory = $true)][string]$AccessToken)

  return Invoke-RestMethod `
    -Uri "https://discord.com/api/v10/users/@me" `
    -Headers @{ Authorization = "Bearer $AccessToken" } `
    -Method GET
}

function Get-DiscordCurrentGuildMember {
  param(
    [Parameter(Mandatory = $true)][string]$AccessToken,
    [Parameter(Mandatory = $true)][string]$GuildId
  )

  return Invoke-RestMethod `
    -Uri "https://discord.com/api/v10/users/@me/guilds/$GuildId/member" `
    -Headers @{ Authorization = "Bearer $AccessToken" } `
    -Method GET
}

function Send-JsonResponse {
  param(
    [Parameter(Mandatory = $true)]$Response,
    [Parameter(Mandatory = $true)][int]$StatusCode,
    [Parameter(Mandatory = $true)]$Payload
  )

  $json = $Payload | ConvertTo-Json -Depth 8
  $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
  $Response.StatusCode = $StatusCode
  $Response.ContentType = "application/json; charset=utf-8"
  $Response.ContentLength64 = $bytes.Length
  $Response.OutputStream.Write($bytes, 0, $bytes.Length)
  $Response.OutputStream.Close()
}

function Send-TextResponse {
  param(
    [Parameter(Mandatory = $true)]$Response,
    [Parameter(Mandatory = $true)][int]$StatusCode,
    [Parameter(Mandatory = $true)][string]$Content,
    [Parameter(Mandatory = $true)][string]$ContentType
  )

  $bytes = [System.Text.Encoding]::UTF8.GetBytes($Content)
  $Response.StatusCode = $StatusCode
  $Response.ContentType = $ContentType
  $Response.ContentLength64 = $bytes.Length
  $Response.OutputStream.Write($bytes, 0, $bytes.Length)
  $Response.OutputStream.Close()
}

function Get-ContentType {
  param([string]$Path)

  switch ([System.IO.Path]::GetExtension($Path).ToLowerInvariant()) {
    ".html" { return "text/html; charset=utf-8" }
    ".css" { return "text/css; charset=utf-8" }
    ".js" { return "application/javascript; charset=utf-8" }
    ".json" { return "application/json; charset=utf-8" }
    ".png" { return "image/png" }
    ".jpg" { return "image/jpeg" }
    ".jpeg" { return "image/jpeg" }
    ".svg" { return "image/svg+xml" }
    ".ico" { return "image/x-icon" }
    default { return "application/octet-stream" }
  }
}

function Send-StaticFile {
  param(
    [Parameter(Mandatory = $true)]$Response,
    [Parameter(Mandatory = $true)][string]$FilePath
  )

  $bytes = [System.IO.File]::ReadAllBytes($FilePath)
  $Response.StatusCode = 200
  $Response.ContentType = Get-ContentType -Path $FilePath
  $Response.ContentLength64 = $bytes.Length
  $Response.OutputStream.Write($bytes, 0, $bytes.Length)
  $Response.OutputStream.Close()
}

function Limit-Text {
  param(
    [AllowNull()][string]$Value,
    [int]$MaxLength = 700
  )

  if ([string]::IsNullOrWhiteSpace($Value)) {
    return "No especificado"
  }

  $trimmed = ($Value -replace "\r?\n+", " ").Trim()
  $trimmed = ($trimmed -replace "\s{2,}", " ")
  if ($trimmed.Length -le $MaxLength) {
    return $trimmed
  }

  return $trimmed.Substring(0, $MaxLength - 3) + "..."
}

function Build-DiscordLines {
  param($Data)

  return @(
    "POSTULACION STAFF - BAJO MUNDO RP"
    ""
    "INFORMACION BASICA"
    "- Discord: $(Limit-Text -Value $Data.discordUsername -MaxLength 180)"
    "- Roblox: $(Limit-Text -Value $Data.robloxUsername -MaxLength 120)"
    "- Edad: $(Limit-Text -Value ([string]$Data.age) -MaxLength 20)"
    "- Pais: $(Limit-Text -Value $Data.country -MaxLength 80)"
    "- Horario disponible: $(Limit-Text -Value $Data.schedule -MaxLength 120)"
    "- Horas al dia: $(Limit-Text -Value ([string]$Data.dailyHours) -MaxLength 20)"
    ""
    "EXPERIENCIA"
    "- Ha sido staff en otros servidores: $(Limit-Text -Value $Data.hasStaffExperience -MaxLength 20)"
    "- Si si, en cuales: $(Limit-Text -Value $Data.previousServers -MaxLength 320)"
    "- Que rango tenia: $(Limit-Text -Value $Data.previousRank -MaxLength 120)"
    "- Por que ya no es staff alli: $(Limit-Text -Value $Data.leftReason -MaxLength 220)"
    "- Tiene experiencia en servidores RP: $(Limit-Text -Value $Data.hasRpExperience -MaxLength 20)"
    ""
    "CONOCIMIENTO DEL SERVIDOR"
    "- Desde cuando esta en Bajo Mundo RP: $(Limit-Text -Value $Data.joinedSince -MaxLength 120)"
    "- Conoce bien las reglas: $(Limit-Text -Value $Data.knowsRules -MaxLength 20)"
    "- Menciona 3 reglas importantes: $(Limit-Text -Value $Data.importantRules)"
    "- Que haria si un usuario rompe una regla grave: $(Limit-Text -Value $Data.severeRuleBreak)"
    ""
    "SITUACIONES"
    "- Si dos usuarios se insultan en chat: $(Limit-Text -Value $Data.chatInsults)"
    "- Si un staff abusa de su poder: $(Limit-Text -Value $Data.abusiveStaff)"
    "- Si un amigo rompe las reglas, lo sanciona: $(Limit-Text -Value $Data.friendBreaksRules)"
    ""
    "ACTITUD Y COMPROMISO"
    "- Por que quiere ser staff: $(Limit-Text -Value $Data.whyStaff)"
    "- Que lo diferencia de otros postulantes: $(Limit-Text -Value $Data.uniqueValue)"
    "- Sabe trabajar en equipo: $(Limit-Text -Value $Data.teamwork -MaxLength 20)"
    "- Aceptaria criticas y supervision: $(Limit-Text -Value $Data.acceptsCriticism -MaxLength 20)"
    ""
    "NORMAS FINALES"
    "- Acepta remocion inmediata por abuso: $(Limit-Text -Value $Data.acceptsRemoval -MaxLength 20)"
    "- Promete ser activo y responsable: $(Limit-Text -Value $Data.promisesActivity -MaxLength 20)"
    "- Confirmo que lei las reglas y la informacion es real: Si"
    ""
    "EXTRA OPCIONAL"
    "- Mini anuncio: $(Limit-Text -Value $Data.miniAnnouncement)"
    "- Que mejoraria en Bajo Mundo RP: $(Limit-Text -Value $Data.serverImprovements)"
  )
}

function Split-DiscordContent {
  param(
    [string[]]$Lines,
    [int]$Limit = 1800
  )

  $chunks = @()
  $current = ""

  foreach ($line in $Lines) {
    $candidate = if ([string]::IsNullOrEmpty($current)) { $line } else { $current + "`n" + $line }

    if ($candidate.Length -le $Limit) {
      $current = $candidate
      continue
    }

    if (-not [string]::IsNullOrEmpty($current)) {
      $chunks += $current
    }

    if ($line.Length -le $Limit) {
      $current = $line
      continue
    }

    $remaining = $line
    while ($remaining.Length -gt $Limit) {
      $chunks += $remaining.Substring(0, $Limit)
      $remaining = $remaining.Substring($Limit)
    }

    $current = $remaining
  }

  if (-not [string]::IsNullOrEmpty($current)) {
    $chunks += $current
  }

  return $chunks
}

function Build-DiscordPayloads {
  param($Data)

  $lines = Build-DiscordLines -Data $Data
  $chunks = @(Split-DiscordContent -Lines $lines)
  $payloads = @()

  for ($i = 0; $i -lt $chunks.Count; $i++) {
    $content = [string]$chunks[$i]
    if ($i -gt 0) {
      $content = "CONTINUA POSTULACION ($($i + 1)/$($chunks.Count))`n`n$content"
    }

    $payloads += (@{
      username = "Bajo Mundo RP Staff"
      content = $content
      allowed_mentions = @{
        parse = @()
      }
    } | ConvertTo-Json -Depth 8)
  }

  return $payloads
}

function Test-ApplicationPayload {
  param($Data)

  if ($null -eq $Data) {
    return @{
      IsValid = $false
      Missing = @("payload")
    }
  }

  $requiredFields = @(
    "robloxUsername",
    "discordUsername",
    "age",
    "country",
    "schedule",
    "dailyHours",
    "hasStaffExperience",
    "hasRpExperience",
    "joinedSince",
    "knowsRules",
    "importantRules",
    "severeRuleBreak",
    "chatInsults",
    "abusiveStaff",
    "friendBreaksRules",
    "whyStaff",
    "uniqueValue",
    "teamwork",
    "acceptsCriticism",
    "acceptsRemoval",
    "promisesActivity"
  )

  $missing = @()
  foreach ($field in $requiredFields) {
    if ([string]::IsNullOrWhiteSpace([string]$Data.$field)) {
      $missing += $field
    }
  }

  if (-not $Data.agreeRules) {
    $missing += "agreeRules"
  }

  return @{
    IsValid = ($missing.Count -eq 0)
    Missing = $missing
  }
}

$rootPath = [System.IO.Path]::GetFullPath($Root)
$listener = [System.Net.HttpListener]::new()
$listener.Prefixes.Add("http://localhost:$Port/")
$listener.Start()

Write-Host ""
Write-Host "Servidor listo en http://localhost:$Port" -ForegroundColor Green
Write-Host "Carpeta publica: $rootPath"

if ([string]::IsNullOrWhiteSpace($WebhookUrl)) {
  Write-Host "Aviso: DISCORD_WEBHOOK_URL no esta configurado. El formulario abrira pero no podra enviar a Discord." -ForegroundColor Yellow
}

try {
  while ($listener.IsListening) {
    $context = $listener.GetContext()
    $request = $context.Request
    $response = $context.Response
    $method = $request.HttpMethod.ToUpperInvariant()
    $path = [System.Uri]::UnescapeDataString($request.Url.AbsolutePath)
    $session = Get-OrCreate-Session -Request $request -Response $response

    try {
      if ($method -eq "OPTIONS") {
        $response.StatusCode = 204
        $response.OutputStream.Close()
        continue
      }

      if ($path -eq "/api/auth/session" -and $method -eq "GET") {
        Send-JsonResponse -Response $response -StatusCode 200 -Payload @{
          ok = $true
          authenticated = [bool]$session.Data.Authenticated
          verifiedGuildMember = [bool]$session.Data.VerifiedGuildMember
          discordUsername = [string]$session.Data.DiscordUsername
          discordUserId = [string]$session.Data.DiscordUserId
        }
        continue
      }

      if ($path -eq "/api/auth/discord/login" -and $method -eq "GET") {
        $clientId = Get-DiscordConfigValue -Name "clientId"
        $redirectUri = Get-DiscordConfigValue -Name "redirectUri"

        if ([string]::IsNullOrWhiteSpace($clientId) -or [string]::IsNullOrWhiteSpace($redirectUri)) {
          Send-JsonResponse -Response $response -StatusCode 500 -Payload @{
            ok = $false
            message = "Falta configurar Discord OAuth."
          }
          continue
        }

        $state = New-RandomToken
        $session.Data.OAuthState = $state
        $script:Sessions[$session.Id] = $session.Data

        $authUrl = Get-DiscordAuthorizationUrl -ClientId $clientId -RedirectUri $redirectUri -State $state
        Send-RedirectResponse -Response $response -Location $authUrl
        continue
      }

      if ($path -eq "/api/auth/discord/callback" -and $method -eq "GET") {
        $clientId = Get-DiscordConfigValue -Name "clientId"
        $clientSecret = Get-DiscordConfigValue -Name "clientSecret"
        $guildId = Get-DiscordConfigValue -Name "guildId"
        $redirectUri = Get-DiscordConfigValue -Name "redirectUri"

        $code = $request.QueryString["code"]
        $state = $request.QueryString["state"]

        if ([string]::IsNullOrWhiteSpace($code) -or [string]::IsNullOrWhiteSpace($state)) {
          Send-RedirectResponse -Response $response -Location "/?discord=error"
          continue
        }

        if ($state -ne [string]$session.Data.OAuthState) {
          Send-RedirectResponse -Response $response -Location "/?discord=state_error"
          continue
        }

        try {
          $token = Get-DiscordOAuthToken -ClientId $clientId -ClientSecret $clientSecret -RedirectUri $redirectUri -Code $code
          $user = Get-DiscordCurrentUser -AccessToken $token.access_token
          $null = Get-DiscordCurrentGuildMember -AccessToken $token.access_token -GuildId $guildId

          $displayName = if (-not [string]::IsNullOrWhiteSpace([string]$user.global_name)) { [string]$user.global_name } else { [string]$user.username }
          $session.Data.Authenticated = $true
          $session.Data.VerifiedGuildMember = $true
          $session.Data.DiscordUsername = "$displayName (@$($user.username)) | $($user.id)"
          $session.Data.DiscordUserId = [string]$user.id
          $session.Data.OAuthState = ""
          $script:Sessions[$session.Id] = $session.Data

          Send-RedirectResponse -Response $response -Location "/?discord=verified"
          continue
        } catch {
          $statusCode = Get-StatusCodeFromException -Exception $_.Exception
          $session.Data.Authenticated = $false
          $session.Data.VerifiedGuildMember = $false
          $session.Data.DiscordUsername = ""
          $session.Data.DiscordUserId = ""
          $session.Data.OAuthState = ""
          $script:Sessions[$session.Id] = $session.Data

          if ($statusCode -eq 404) {
            Send-RedirectResponse -Response $response -Location "/?discord=not_in_server"
            continue
          }

          Send-RedirectResponse -Response $response -Location "/?discord=error"
          continue
        }
      }

      if ($path -eq "/api/auth/discord/logout" -and $method -eq "POST") {
        $session.Data.Authenticated = $false
        $session.Data.VerifiedGuildMember = $false
        $session.Data.DiscordUsername = ""
        $session.Data.DiscordUserId = ""
        $session.Data.OAuthState = ""
        $script:Sessions[$session.Id] = $session.Data

        Send-JsonResponse -Response $response -StatusCode 200 -Payload @{
          ok = $true
        }
        continue
      }

      if ($path -eq "/api/postulacion" -and $method -eq "POST") {
        if ([string]::IsNullOrWhiteSpace($WebhookUrl)) {
          Send-JsonResponse -Response $response -StatusCode 500 -Payload @{
            ok = $false
            message = "Configura DISCORD_WEBHOOK_URL antes de enviar postulaciones."
          }
          continue
        }

        $reader = New-Object System.IO.StreamReader($request.InputStream, $request.ContentEncoding)
        $body = $reader.ReadToEnd()
        $reader.Dispose()

        $data = $body | ConvertFrom-Json

        if (-not [bool]$session.Data.VerifiedGuildMember) {
          Send-JsonResponse -Response $response -StatusCode 403 -Payload @{
            ok = $false
            message = "Debes verificar tu cuenta de Discord antes de enviar la postulacion."
          }
          continue
        }

        $data.discordUsername = [string]$session.Data.DiscordUsername
        $validation = Test-ApplicationPayload -Data $data

        if (-not $validation.IsValid) {
          Send-JsonResponse -Response $response -StatusCode 400 -Payload @{
            ok = $false
            message = "Faltan campos obligatorios: $($validation.Missing -join ', ')"
          }
          continue
        }

        $discordPayloads = Build-DiscordPayloads -Data $data
        foreach ($discordBody in $discordPayloads) {
          Invoke-RestMethod -Uri $WebhookUrl -Method POST -ContentType "application/json" -Body $discordBody | Out-Null
        }

        Send-JsonResponse -Response $response -StatusCode 200 -Payload @{
          ok = $true
          message = "Postulacion enviada correctamente."
        }
        continue
      }

      if ($method -ne "GET") {
        Send-JsonResponse -Response $response -StatusCode 405 -Payload @{
          ok = $false
          message = "Metodo no permitido."
        }
        continue
      }

      $relativePath = if ($path -eq "/") { "index.html" } else { $path.TrimStart("/") }
      $fullPath = [System.IO.Path]::GetFullPath((Join-Path $rootPath $relativePath))

      if (-not $fullPath.StartsWith($rootPath, [System.StringComparison]::OrdinalIgnoreCase)) {
        Send-JsonResponse -Response $response -StatusCode 403 -Payload @{
          ok = $false
          message = "Ruta no permitida."
        }
        continue
      }

      if ((Test-Path -LiteralPath $fullPath -PathType Container)) {
        $fullPath = Join-Path $fullPath "index.html"
      }

      if (-not (Test-Path -LiteralPath $fullPath -PathType Leaf)) {
        Send-TextResponse -Response $response -StatusCode 404 -Content "404 - No encontrado" -ContentType "text/plain; charset=utf-8"
        continue
      }

      Send-StaticFile -Response $response -FilePath $fullPath
    } catch {
      Send-JsonResponse -Response $response -StatusCode 500 -Payload @{
        ok = $false
        message = $_.Exception.Message
      }
    }
  }
} finally {
  $listener.Stop()
  $listener.Close()
}
