const form = document.getElementById("applicationForm");
const statusNode = document.getElementById("formStatus");
const draftKey = "staff-application-draft";
const applicationArea = document.getElementById("applicationArea");
const thankYouScreen = document.getElementById("thankYouScreen");
const stepAccount = document.getElementById("stepAccount");
const stepQuestions = document.getElementById("stepQuestions");
const verifyDiscordButton = document.getElementById("verifyDiscordButton");
const toQuestionsButton = document.getElementById("toQuestionsButton");
const backToAccountButton = document.getElementById("backToAccountButton");
const restartFormButton = document.getElementById("restartFormButton");
const discordVerifyState = document.getElementById("discordVerifyState");
const stepIndicators = document.querySelectorAll("[data-step-indicator]");
const accountFields = ["robloxUsername", "discordUsername"];
const questionFields = [
  "age",
  "country",
  "schedule",
  "dailyHours",
  "hasStaffExperience",
  "previousServers",
  "previousRank",
  "leftReason",
  "hasRpExperience",
  "joinedSince",
  "knowsRules",
  "importantRules",
  "severeRuleBreak",
  "chatInsults",
  "abusiveStaff",
  "friendBreaksRules",
  "whyStaff",
  "uniqueValue",
  "teamwork",
  "acceptsCriticism",
  "acceptsRemoval",
  "promisesActivity",
  "miniAnnouncement",
  "serverImprovements"
];
const discordField = form.elements.namedItem("discordUsername");
const firstQuestionField = form.elements.namedItem("age");
let currentStep = 1;
let accountReady = false;
let discordVerified = false;
let backendAvailable = true;

function setStatus(message, type = "") {
  statusNode.textContent = message;
  statusNode.className = "status-message";

  if (type) {
    statusNode.classList.add(type);
  }
}

function showApplicationScreen() {
  applicationArea.hidden = false;
  thankYouScreen.hidden = true;
}

function showThankYouScreen() {
  applicationArea.hidden = true;
  thankYouScreen.hidden = false;
}

function updateAccountReady() {
  const robloxOk = hasValue("robloxUsername");
  setAccountReady(discordVerified && robloxOk);
}

function setStep(step) {
  currentStep = step;
  stepAccount.hidden = step !== 1;
  stepQuestions.hidden = step !== 2;

  stepIndicators.forEach((indicator) => {
    indicator.classList.toggle("active", Number(indicator.dataset.stepIndicator) === step);
  });
}

function setAccountReady(value) {
  accountReady = value;
  toQuestionsButton.disabled = !value;
}

function setDiscordVerification(verified, username = "") {
  discordVerified = verified;
  discordField.value = username;

  if (verified) {
    discordVerifyState.textContent = "Cuenta verificada correctamente en Bajo Mundo RP.";
    discordVerifyState.className = "discord-verify-state success";
    verifyDiscordButton.textContent = "Cambiar cuenta";
  } else {
    discordVerifyState.textContent = "Debes verificar tu cuenta de Discord para continuar.";
    discordVerifyState.className = "discord-verify-state";
    verifyDiscordButton.textContent = "Verificar con Discord";
  }

  updateAccountReady();
}

function focusField(field) {
  if (!field) {
    return;
  }

  window.setTimeout(() => {
    field.focus();
  }, 120);
}

function focusAccessStart() {
  if (discordVerified) {
    focusField(form.elements.namedItem("robloxUsername"));
    return;
  }

  focusField(verifyDiscordButton);
}

function validateFields(fieldNames) {
  for (const name of fieldNames) {
    const field = form.elements.namedItem(name);
    if (!field) {
      continue;
    }

    if (!field.checkValidity()) {
      field.reportValidity();
      return false;
    }
  }

  return true;
}

function saveDraft() {
  const formData = new FormData(form);
  const draft = {};

  for (const [key, value] of formData.entries()) {
    draft[key] = value;
  }

  draft.agreeRules = form.querySelector('input[name="agreeRules"]').checked;
  localStorage.setItem(draftKey, JSON.stringify(draft));
}

function loadDraft() {
  try {
    const rawDraft = localStorage.getItem(draftKey);
    if (!rawDraft) {
      return;
    }

    const draft = JSON.parse(rawDraft);
    Object.entries(draft).forEach(([key, value]) => {
      const field = form.elements.namedItem(key);
      if (!field) {
        return;
      }

      if (field.type === "checkbox") {
        field.checked = Boolean(value);
      } else {
        field.value = value;
      }
    });
  } catch (error) {
    localStorage.removeItem(draftKey);
  }
}

function getPayload() {
  const formData = new FormData(form);

  return {
    robloxUsername: (formData.get("robloxUsername") || "").toString().trim(),
    discordUsername: (formData.get("discordUsername") || "").toString().trim(),
    age: (formData.get("age") || "").toString().trim(),
    country: (formData.get("country") || "").toString().trim(),
    schedule: (formData.get("schedule") || "").toString().trim(),
    dailyHours: (formData.get("dailyHours") || "").toString().trim(),
    hasStaffExperience: (formData.get("hasStaffExperience") || "").toString().trim(),
    previousServers: (formData.get("previousServers") || "").toString().trim(),
    previousRank: (formData.get("previousRank") || "").toString().trim(),
    leftReason: (formData.get("leftReason") || "").toString().trim(),
    hasRpExperience: (formData.get("hasRpExperience") || "").toString().trim(),
    joinedSince: (formData.get("joinedSince") || "").toString().trim(),
    knowsRules: (formData.get("knowsRules") || "").toString().trim(),
    importantRules: (formData.get("importantRules") || "").toString().trim(),
    severeRuleBreak: (formData.get("severeRuleBreak") || "").toString().trim(),
    chatInsults: (formData.get("chatInsults") || "").toString().trim(),
    abusiveStaff: (formData.get("abusiveStaff") || "").toString().trim(),
    friendBreaksRules: (formData.get("friendBreaksRules") || "").toString().trim(),
    whyStaff: (formData.get("whyStaff") || "").toString().trim(),
    uniqueValue: (formData.get("uniqueValue") || "").toString().trim(),
    teamwork: (formData.get("teamwork") || "").toString().trim(),
    acceptsCriticism: (formData.get("acceptsCriticism") || "").toString().trim(),
    acceptsRemoval: (formData.get("acceptsRemoval") || "").toString().trim(),
    promisesActivity: (formData.get("promisesActivity") || "").toString().trim(),
    miniAnnouncement: (formData.get("miniAnnouncement") || "").toString().trim(),
    serverImprovements: (formData.get("serverImprovements") || "").toString().trim(),
    agreeRules: form.querySelector('input[name="agreeRules"]').checked
  };
}

function hasValue(name) {
  const field = form.elements.namedItem(name);
  return Boolean(field && String(field.value || "").trim());
}

function createAppError(message, code = "") {
  const error = new Error(message);
  error.code = code;
  return error;
}

function isBackendUnavailableError(error) {
  return error instanceof TypeError || (error instanceof Error && error.code === "backend_unavailable");
}

function getErrorMessage(error, fallbackMessage, backendMessage) {
  if (error instanceof TypeError) {
    return backendMessage;
  }

  if (error instanceof Error && error.message) {
    return error.message;
  }

  return fallbackMessage;
}

async function readApiResponse(response, options = {}) {
  const fallbackMessage = options.fallbackMessage || "La solicitud no se pudo completar.";
  const nonJsonMessage = options.nonJsonMessage || "El backend no devolvio JSON.";
  const contentType = String(response.headers.get("content-type") || "").toLowerCase();
  const rawBody = await response.text();
  const expectsJson = contentType.includes("application/json");
  let data = null;

  if (rawBody && expectsJson) {
    try {
      data = JSON.parse(rawBody);
    } catch {
      throw createAppError("El servidor respondio con un JSON invalido.", "invalid_json");
    }
  }

  if (!response.ok) {
    if (data && typeof data.message === "string" && data.message.trim()) {
      throw createAppError(data.message);
    }

    if (!expectsJson) {
      throw createAppError(nonJsonMessage, "backend_unavailable");
    }

    throw createAppError(fallbackMessage);
  }

  if (!expectsJson) {
    throw createAppError(nonJsonMessage, "backend_unavailable");
  }

  return data || {};
}

async function syncDiscordSession() {
  try {
    const response = await fetch("/api/auth/session", {
      method: "GET",
      headers: {
        "Accept": "application/json"
      }
    });

    const data = await readApiResponse(response, {
      fallbackMessage: "No se pudo consultar la sesion de Discord.",
      nonJsonMessage: "La ruta /api/auth/session no existe en este deploy. Falta el backend que maneja la verificacion con Discord."
    });
    backendAvailable = true;

    setDiscordVerification(Boolean(data.verifiedGuildMember), data.discordUsername || "");

    if (discordVerified && questionFields.some(hasValue)) {
      setStep(2);
      focusField(firstQuestionField);
    } else {
      setStep(1);
      focusAccessStart();
    }
  } catch (error) {
    if (isBackendUnavailableError(error)) {
      backendAvailable = false;
    }

    setDiscordVerification(false, "");
    setStep(1);
    setStatus(
      getErrorMessage(
        error,
        "No se pudo verificar la sesion de Discord.",
        "No se pudo conectar con el backend de Discord. Si usas Netlify, revisa las funciones /api y las variables de entorno."
      ),
      "error"
    );
    focusAccessStart();
  }
}

function applyDiscordStatusFromUrl() {
  const url = new URL(window.location.href);
  const discordStatus = url.searchParams.get("discord");

  if (discordStatus === "verified") {
    setStatus("Discord verificado correctamente. Ya puedes entrar al formulario.", "success");
  } else if (discordStatus === "not_in_server") {
    setStatus("Tu cuenta de Discord no esta dentro de Bajo Mundo RP.", "error");
  } else if (discordStatus === "state_error") {
    setStatus("La verificacion de Discord no se pudo completar. Intentalo otra vez.", "error");
  } else if (discordStatus === "error") {
    setStatus("Hubo un error al verificar tu cuenta de Discord.", "error");
  }

  if (discordStatus) {
    url.searchParams.delete("discord");
    window.history.replaceState({}, "", url.pathname + (url.search ? "?" + url.searchParams.toString() : ""));
  }
}

async function submitApplication(event) {
  event.preventDefault();
  setStatus("");

  if (!discordVerified) {
    setStep(1);
    setStatus("Debes verificar tu cuenta de Discord antes de continuar.", "error");
    return;
  }

  if (!validateFields(accountFields)) {
    setStep(1);
    setStatus("Primero completa tu nombre en Roblox.", "error");
    return;
  }

  if (currentStep === 1) {
    if (accountReady) {
      setStep(2);
      setStatus("Ahora completa el formulario.", "success");
      focusField(firstQuestionField);
    } else if (!hasValue("robloxUsername")) {
      setStatus("Escribe tu nombre en Roblox para continuar.", "error");
    }
    return;
  }

  if (!form.reportValidity()) {
    setStatus("Revisa los campos obligatorios antes de enviar.", "error");
    return;
  }

  const payload = getPayload();
  const button = form.querySelector('button[type="submit"]');

  button.disabled = true;
  button.textContent = "Enviando...";
  setStatus("Mandando postulacion al panel de staff...");

  try {
    const response = await fetch("/api/postulacion", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload)
    });

    const data = await readApiResponse(response, {
      fallbackMessage: "No se pudo enviar la postulacion.",
      nonJsonMessage: "La ruta /api/postulacion no existe en este deploy. Falta el backend que envia la postulacion a Discord."
    });
    backendAvailable = true;

    form.reset();
    localStorage.removeItem(draftKey);
    setStep(1);
    setAccountReady(false);
    setStatus("");
    showThankYouScreen();
  } catch (error) {
    if (isBackendUnavailableError(error)) {
      backendAvailable = false;
    }

    setStatus(
      getErrorMessage(
        error,
        "Ocurrio un error al enviar la postulacion.",
        "No se pudo conectar con el backend del formulario. Si usas Netlify, revisa las funciones /api y las variables de entorno."
      ),
      "error"
    );
  } finally {
    button.disabled = false;
    button.textContent = "Enviar postulacion";
  }
}

loadDraft();
showApplicationScreen();
applyDiscordStatusFromUrl();
setDiscordVerification(false, "");
syncDiscordSession();

if (discordVerified && questionFields.some(hasValue)) {
  setStep(2);
} else {
  setStep(1);
}

if (currentStep === 2) {
  focusField(firstQuestionField);
} else {
  focusAccessStart();
}

form.addEventListener("input", saveDraft);
form.addEventListener("change", saveDraft);
form.addEventListener("submit", submitApplication);
form.elements.namedItem("robloxUsername").addEventListener("input", updateAccountReady);

verifyDiscordButton.addEventListener("click", async () => {
  if (discordVerified) {
    try {
      const response = await fetch("/api/auth/discord/logout", {
        method: "POST"
      });

      await readApiResponse(response, {
        fallbackMessage: "No se pudo cerrar la sesion de Discord.",
        nonJsonMessage: "La ruta /api/auth/discord/logout no existe en este deploy."
      });
      backendAvailable = true;
      setDiscordVerification(false, "");
      setStatus("Sesion de Discord cerrada. Puedes verificar otra cuenta.", "success");
      focusAccessStart();
    } catch (error) {
      if (isBackendUnavailableError(error)) {
        backendAvailable = false;
      }

      setStatus(
        getErrorMessage(
          error,
          "No se pudo cerrar la sesion de Discord.",
          "No se pudo conectar con el backend de Discord. Si usas Netlify, revisa las funciones /api y las variables de entorno."
        ),
        "error"
      );
    }
    return;
  }

  if (!backendAvailable) {
    setStatus("La verificacion con Discord no esta disponible en este deploy. Si usas Netlify, configura las funciones /api y las variables de entorno.", "error");
    return;
  }

  window.location.href = "/api/auth/discord/login";
});

toQuestionsButton.addEventListener("click", () => {
  if (!discordVerified) {
    setStatus("Primero verifica tu cuenta de Discord.", "error");
    return;
  }

  if (!hasValue("robloxUsername")) {
    setStatus("Escribe tu nombre en Roblox.", "error");
    return;
  }

  setStep(2);
  setStatus("Ahora completa el formulario.", "success");
  focusField(firstQuestionField);
});

backToAccountButton.addEventListener("click", () => {
  setStep(1);
  setStatus("Puedes editar tu acceso antes de continuar.", "success");
  focusAccessStart();
});

restartFormButton.addEventListener("click", () => {
  showApplicationScreen();
  setStep(1);
  updateAccountReady();
  setStatus("");
  focusAccessStart();
});

if (window.location.protocol === "file:") {
  setStatus("Abre esta pagina desde el servidor local para que el envio a Discord funcione.", "error");
}
