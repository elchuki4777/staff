const {
  commitSession,
  getDiscordAuthorizationUrl,
  getDiscordConfig,
  getMissingConfig,
  json,
  randomToken,
  readSession,
  redirect
} = require("./shared");

exports.handler = async (event) => {
  if (event.httpMethod !== "GET") {
    return json(405, {
      ok: false,
      message: "Metodo no permitido."
    });
  }

  const config = getDiscordConfig(event);
  const missing = getMissingConfig(config, ["clientId", "clientSecret", "redirectUri", "guildId"]);
  const missingLabels = missing.map((key) => ({
    clientId: "DISCORD_CLIENT_ID",
    clientSecret: "DISCORD_CLIENT_SECRET",
    redirectUri: "DISCORD_REDIRECT_URI",
    guildId: "DISCORD_GUILD_ID"
  }[key] || key));

  if (missing.length > 0) {
    return json(500, {
      ok: false,
      message: `Falta configurar Discord OAuth en Netlify. Variables faltantes: ${missingLabels.join(", ")}`
    });
  }

  const session = readSession(event);
  session.oauthState = randomToken();

  return redirect(getDiscordAuthorizationUrl(config, session.oauthState), {
    headers: {
      "Set-Cookie": commitSession(event, session)
    }
  });
};
